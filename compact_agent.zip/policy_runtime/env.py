"""Small .env loader that never logs or overwrites existing secrets."""

from __future__ import annotations

import os
from pathlib import Path


def load_dotenv(path: str | Path) -> None:
    env_path = Path(path)
    if not env_path.is_file():
        return
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key in {
            "OPENAI_API_KEY",
            "OPENAI_MODEL",
            "OPENAI_BASE_URL",
            "OPENAI_TIMEOUT_SECONDS",
            "GEMINI_API_KEY",
            "GOOGLE_API_KEY",
            "GEMINI_MODEL",
            "GEMINI_BASE_URL",
            "GEMINI_TIMEOUT_SECONDS",
            "GROQ_API_KEY",
            "GROQ_MODEL",
            "GROQ_BASE_URL",
            "GROQ_TIMEOUT_SECONDS",
        }:
            os.environ.setdefault(key, value)
